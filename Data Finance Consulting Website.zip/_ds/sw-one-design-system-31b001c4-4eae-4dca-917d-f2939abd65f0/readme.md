# SW ONE — Design System

The brand and UI system for **SW ONE**, the enterprise accounting/ERP suite built by
**บริษัท เอส ดับเบิลยู สแตรทีจิก โซลูชันส์ กรุ๊ป จำกัด / SW Strategic Solutions Group Co., Ltd.**
SW ONE is a Thai-first, double-entry accounting platform for VAT-registered service businesses —
covering journals, documents (invoice/receipt/contract), Thai tax (ภ.พ.30, ภ.ง.ด.), financial
statements, cash-flow (its #1 priority), CRM, inventory, POS, HR/payroll and a To-Do board.

- **Product name:** SW ONE · subtitle "Enterprise Business Suite"
- **Company:** SW Strategic Solutions Group Co., Ltd. · นิติบุคคล 0125569020330 · โทร 0641549955
- **Default language:** Thai (with TH / EN / 中文 switcher)
- **Owners / signatories:** วีระชัย สุวัจน์วณิช, ศิญาภัสร์

## Source
Recreated from the product codebase mounted at **`Acc_Program/`** (Cloudflare Workers + Hono + D1 +
vanilla-JS SPA). The brand truth lives in `Acc_Program/public/index.html` (the single-file SPA),
`Acc_Program/seed.sql` (theme colours, company settings) and `Acc_Program/CLAUDE.md` (the product
spec). Brand assets copied from `Acc_Program/public/`. The reader is not assumed to have access —
these paths are recorded for whoever does.

---

## CONTENT FUNDAMENTALS — how SW ONE writes

- **Language:** Thai-first, always. UI labels, buttons, table headers, hints are Thai. English appears
  as a secondary line on documents (bilingual financial statements) and accounting terms
  (`Accounts Receivable`, `Cash Flow`). Chinese is a third option for Chinese-owned Thai businesses.
- **Tone:** plain, practical, reassuring. The product is explicitly built for users *without* an
  accounting background, so every important figure carries the correct financial term **plus** a
  plain-language tooltip. Copy explains, it doesn't lecture.
- **Voice:** neutral/system, not first-person. It addresses the user through clear nouns and verbs
  ("เลือกผู้ใช้", "บันทึก", "ยังบันทึกไม่ได้: ต้องดุล") rather than "I/you" chattiness.
- **Casing:** Thai has no case. The Latin wordmark "SW ONE" is all-caps; the eyebrow
  "ENTERPRISE BUSINESS SUITE" is uppercase tracked. Accounting codes stay as-is (`ภ.พ.30`, `O2C`, `WHT`).
- **Numbers & money:** Baht with `฿` prefix, two decimals, Thai locale grouping
  (`฿1,284,500.00`). Stored internally as satang (integers). Always tabular/right-aligned in tables.
- **Emoji:** **yes — emoji are part of the product's visual language.** They prefix labels and
  buttons as compact icons: 📥 รับงาน · ⏱ ระยะเวลา · 🎯 กำหนดส่ง · 💾 บันทึก · 🖨 PDF · ⬇ Excel ·
  📲 ติดตั้งแอป · 🔍 กรอง · 🟢🟡🔴 status. Use them the way the product does — as leading glyphs on
  actions and statuses, never as decorative filler.
- **Examples of real copy:** "เข้าสู่ระบบ" · "ระบบบัญชี ERP" · "งบกระแสเงินสด (Direct) — Priority 1" ·
  "⚠️ รายการนี้แตะเงินสด — ทุกขาที่ไม่ใช่เงินสดต้องระบุกิจกรรม" · "พบ 24 งาน".

---

## VISUAL FOUNDATIONS

- **Palette — premium, modern-minimal.** A deep brand green leads: primary `#1B6B4C` (actions,
  active emphasis), hover `#134E38`, link/secondary green `#2E8460`. Mint `#BFE3D2` is now a quiet
  *tint* (chips, washes), not a fill; airy sage `#EDF4EF` for sunken surfaces; soft cool paper
  `#F6F8F6` canvas. Text is a near-black forest ink `#16201B`, hints `#66716A`, hairlines a light
  `#E7ECE8`. **Gold `#C8A24A` (from the Yggdrasil logo motif) is the premium accent** — used sparingly
  for fine detail, never as a fill. Dusty rose `#DB9B9B` is kept as an optional warm secondary.
  Surfaces stay white and uncluttered; colour appears as ink, not as panels. Theme is user-adjustable
  in the product (`theme_*`). Brand secondary colours from logo/login: navy `#1F2A44`, bark `#5E6B52`,
  leaf `#8FB39A`, gold `#C8A24A`.
- **Status = traffic light.** 🟢 good `#5A9E7A`, 🟡 warn `#D8A657`, 🔴 bad `#C96A6A`, each with a soft
  tint background for capsules. Used everywhere: filing status, AR/AP aging, balanced/unbalanced, variance.
- **Type.** Body, UI and the wordmark are all **IBM Plex Sans Thai** (with IBM Plex Sans for Latin
  hand-off) — one cohesive modern, technical-premium family with excellent numerals; loaded from
  Google Fonts, dense 15px base, never below ~13px. The wordmark is the same face at 600 with tight
  1px tracking. (Replaces the earlier Sarabun + Playfair pairing.) Money/figures use
  `font-variant-numeric: tabular-nums`.
- **Dark / Premium Navy mode.** Opt-in via `<html data-theme="dark">` (see `tokens/dark.css`). Only
  semantic aliases are remapped, so every token-driven component flips automatically: deep navy
  surfaces (`#0E1525` canvas, `#16203A` cards), cool near-white text, and **gold `#CDA64E` promoted to
  the hero accent** — primary buttons, rules and links turn gold on navy. The ERP UI kit has a
  🌙 มืด / ☀️ สว่าง toggle in its header, and the **login** has its own premium dark treatment — a deep
  navy radial gradient with **glowing gold Yggdrasil corners** and a gold CTA.
- **Gold is the premium accent** (from the Yggdrasil logo nodes): in light mode it rules the document
  letterhead (2px gold underline + gold document title) and fine detail; in dark mode it leads.
- **Backgrounds.** Flat cool-paper canvas; white cards on top. **No photography, no gradients in-app**
  — the *one* gradient is the login (mint → sage). No textures or patterns except the Yggdrasil
  corner SVG on the login. Documents print on plain white.
- **Cards.** White, 1px light hairline `#E7ECE8`, 16px radius, 20px padding, soft **layered** shadow
  (`0 1px 2px / 0 12px 28px -20px`) so panels float gently on the cool paper. The universal container.
  KPI tiles are maximally minimal — just an uppercase tracked caption, a large near-black figure and
  an optional discreet trend figure. No rails, no fills: the number carries the card.
- **Corners.** Soft, airy: 7px tags · 10px inputs/buttons · 14px columns · 16px cards · 20px modals ·
  full-capsule pills · 24px login card · full circles for avatars.
- **Shadows.** Soft, layered, low-opacity — used for elevation only. Buttons rest on a neutral 1–2px
  lift; the gated "ready" state adds a subtle green glow (no heavy drop shadows anywhere).
- **Buttons & states.** Primary = deep brand-green fill, white text, subtle neutral lift; secondary =
  soft mint; ghost = paper + hairline. Gated form actions (login, post-journal, add-partner) stay **disabled + greyed (38% opacity,
  slight grayscale)** until valid, then snap to a deeper green with a subtle glow — strong affordance that the
  action is now safe. Hover darkens the accent; there are no bounces or playful motion. Transitions
  are short fades on background/shadow/opacity (~.15s).
- **Borders & rules.** Tables are borderless except a 1px bottom rule per row; headers are muted.
  Document letterheads use a 2px mint underline.
- **Layout.** Full-width ERP (no centered max-width column); 22px×32px main padding; sticky white
  app header; clean white group nav with a soft mint **pill** marking the active item; white chip
  sub-nav. Generous whitespace; information-dense but never cramped.
- **Transparency / blur.** Barely used — only the login's subtle frosted note and modal scrims
  (`rgba(0,0,0,.45)`). The product favours solid, legible surfaces.
- **Imagery vibe.** The only raster is the metallic-silver knight logo and the owner's signature PNG.
  Cool silver on white/navy. No stock imagery anywhere.

---

## ICONOGRAPHY

SW ONE has **no icon font and almost no SVG icon set** — its icon language is **emoji**, used
inline as leading glyphs on labels, buttons and statuses (see Content Fundamentals). Treat emoji as
first-class UI icons here; match the product's choices (💾 save, 🖨 print, ⬇ export, 📲 install,
📥/⏱/🎯 task fields, 🟢🟡🔴 status, ⚠️ warnings, 📎 attach, ✏️ edit, ✕ delete, 🔍 filter, 📄/📝/🧾 docs).

Genuine vector art is limited to two brand marks, both copied into `assets/`:
- **`assets/logo-sw.jpg`** — the silver chess-knight logo (strategy → "Strategic Solutions").
- **`assets/yggdrasil-vine.svg`** — the branching vine + gold "wisdom node" motif that frames the
  four corners of the login (recreated from the inline SVG in the product).
- **`assets/signature-veerachai.png`** — the authorised signatory's signature, used on documents.

Charts in the product are **Chart.js** (doughnut + bar) in mint/rose/gold; recreations here use
lightweight CSS equivalents. If you need UI glyphs beyond emoji, prefer a thin-stroke CDN set
(e.g. Lucide) and flag it — the source ships none.

---

## INDEX — what's in this system

**Foundations** (root)
- `styles.css` — the single entry point consumers link (import-only).
- `tokens/colors.css` · `tokens/typography.css` · `tokens/spacing.css` · `tokens/fonts.css` ·
  `tokens/dark.css` (the `[data-theme="dark"]` Premium Navy scope)
  — CSS custom properties + the IBM Plex Sans Thai webfont import.

**Specimen cards** (`guidelines/*.html`) — render in the Design System tab, grouped Type / Colors /
Spacing / Brand (wordmark, body scale, numerics; pastels, neutrals, status, brand wood; radii,
shadows, spacing; logo, Yggdrasil motif, document letterhead).

**Components** (`components/<group>/`) — React primitives on `window.SWONEDesignSystem_31b001`:
- `core/` — `Button`, `Badge`, `KpiCard`, `Card`
- `forms/` — `TextField`, `Select`
- `navigation/` — `GroupNav`, `SubNavChips`
- `data/` — `DataTable`
- `board/` — `TaskCard`

Each has `<Name>.jsx` + `<Name>.d.ts` + `<Name>.prompt.md` and a `@dsCard` showcase HTML.

**UI kit** (`ui_kits/sw-one-erp/`) — interactive recreation: login → dashboard, journal (the
double-entry + cash-flow-gating signature view), tax invoice, kanban. See its `README.md`.

**Assets** (`assets/`) — `logo-sw.jpg`, `yggdrasil-vine.svg` (light), `yggdrasil-vine-gold.svg`
(glowing gold, for dark mode), `signature-veerachai.png`.

**`SKILL.md`** — Agent-Skills-compatible entry point for using this system in Claude Code.
