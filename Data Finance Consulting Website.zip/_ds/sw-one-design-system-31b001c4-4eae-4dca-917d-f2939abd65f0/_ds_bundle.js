/* @ds-bundle: {"format":3,"namespace":"SWONEDesignSystem_31b001","components":[{"name":"TaskCard","sourcePath":"components/board/TaskCard.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"KpiCard","sourcePath":"components/core/KpiCard.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"GroupNav","sourcePath":"components/navigation/GroupNav.jsx"},{"name":"SubNavChips","sourcePath":"components/navigation/SubNavChips.jsx"}],"sourceHashes":{"components/board/TaskCard.jsx":"554341db5836","components/core/Badge.jsx":"45d0fb8ceabf","components/core/Button.jsx":"736299e0e423","components/core/Card.jsx":"445267dbf7f2","components/core/KpiCard.jsx":"f4de4e64781f","components/data/DataTable.jsx":"68efce494d4e","components/forms/Select.jsx":"8d2f06cab807","components/forms/TextField.jsx":"6e80f7867316","components/navigation/GroupNav.jsx":"d4b8eb4ee8e1","components/navigation/SubNavChips.jsx":"0059b9b78523","ui_kits/sw-one-erp/DashboardScreen.jsx":"ba587e3454c9","ui_kits/sw-one-erp/DocumentsScreen.jsx":"d717aadda53b","ui_kits/sw-one-erp/JournalScreen.jsx":"1e6c8c4ffe69","ui_kits/sw-one-erp/KanbanScreen.jsx":"39260dd9bd19","ui_kits/sw-one-erp/LoginScreen.jsx":"8477cda00868"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SWONEDesignSystem_31b001 = window.SWONEDesignSystem_31b001 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/board/TaskCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SW ONE kanban task card — white card with a priority-coloured left border, as on the
 * To-Do Board. Priority sets the left accent (Urgent/High/Normal/Low). `overdue` turns
 * the due line rose. Draggable styling only; wire your own DnD handlers.
 */
const PRI = {
  Urgent: '#C0392B',
  High: '#E08E0B',
  Normal: 'var(--sw-good)',
  Low: '#9AA7A0'
};
function TaskCard({
  title,
  priority = 'Normal',
  due,
  overdue = false,
  assignee,
  meta,
  children,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("article", _extends({
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--r-lg)',
      padding: 'var(--sp-3)',
      marginBottom: 'var(--sp-2)',
      boxShadow: 'var(--shadow-card)',
      borderLeft: `4px solid ${PRI[priority] || 'var(--sw-line)'}`,
      cursor: 'grab',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 'var(--fw-semibold)',
      fontSize: 'var(--fs-sm)',
      color: 'var(--text-body)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: '6px',
      flexWrap: 'wrap',
      alignItems: 'center',
      marginTop: 'var(--sp-2)',
      fontSize: 'var(--fs-2xs)',
      color: 'var(--sw-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      padding: '1px 8px',
      borderRadius: 'var(--r-lg)',
      fontSize: 'var(--fs-2xs)',
      color: 'var(--sw-white)',
      fontWeight: 'var(--fw-semibold)',
      background: PRI[priority] || 'var(--sw-muted)'
    }
  }, priority), due && /*#__PURE__*/React.createElement("span", {
    style: {
      color: overdue ? 'var(--sw-bad)' : 'inherit',
      fontWeight: overdue ? 'var(--fw-bold)' : 'inherit'
    }
  }, "\uD83D\uDCC5 ", due)), children, assignee && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--sp-2)',
      fontSize: 'var(--fs-2xs)',
      color: 'var(--sw-muted)'
    }
  }, "\uD83D\uDC64 ", assignee), meta);
}
Object.assign(__ds_scope, { TaskCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/board/TaskCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
/**
 * SW ONE status badge / pill. Semantic tones map to the product's traffic-light system
 * (🟢 good / 🟡 warn / 🔴 bad) plus neutral mint/grey. Renders as a rounded capsule.
 * Set `dot` for the leading status dot used on tax-calendar / aging rows.
 */
function Badge({
  children,
  tone = 'neutral',
  dot = false,
  solid = false,
  style = {}
}) {
  const map = {
    good: {
      fg: 'var(--sw-good)',
      bg: 'var(--sw-good-bg)',
      solidBg: 'var(--sw-good)'
    },
    warn: {
      fg: '#8a6418',
      bg: 'var(--sw-warn-bg)',
      solidBg: 'var(--sw-warn)'
    },
    bad: {
      fg: 'var(--sw-bad)',
      bg: 'var(--sw-bad-bg)',
      solidBg: 'var(--sw-bad)'
    },
    mint: {
      fg: 'var(--sw-ink)',
      bg: 'var(--sw-mint)',
      solidBg: 'var(--sw-mint-700)'
    },
    accent: {
      fg: 'var(--sw-white)',
      bg: 'var(--accent)',
      solidBg: 'var(--accent)'
    },
    neutral: {
      fg: 'var(--sw-muted)',
      bg: 'var(--surface-raised)',
      solidBg: 'var(--sw-muted)'
    }
  };
  const c = map[tone] || map.neutral;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '5px',
      padding: '2px 9px',
      borderRadius: 'var(--r-pill)',
      fontSize: 'var(--fs-2xs)',
      fontWeight: 'var(--fw-semibold)',
      fontFamily: 'var(--font-body)',
      color: solid ? 'var(--sw-white)' : c.fg,
      background: solid ? c.solidBg : c.bg,
      whiteSpace: 'nowrap',
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: '7px',
      height: '7px',
      borderRadius: 'var(--r-full)',
      background: solid ? 'var(--sw-white)' : c.fg
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SW ONE Button.
 * Three variants matching the product's `.btn`, `.btn.sec`, `.btn.ghost`:
 *  - primary   → dusty-rose fill, soft rose-tinted lift shadow
 *  - secondary → mint fill, ink text
 *  - ghost     → cream fill with hairline border
 * `ready` mirrors the product's emphasised ready-state (deeper rose + glow) used on
 * forms that gate the action until valid (login, post-journal, add-partner).
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  icon = null,
  disabled = false,
  ready = false,
  type = 'button',
  onClick,
  style = {},
  ...rest
}) {
  const pad = size === 'sm' ? '6px 12px' : '9px 16px';
  const fs = size === 'sm' ? 'var(--fs-xs)' : 'var(--fs-sm)';
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '6px',
    fontFamily: 'var(--font-body)',
    fontWeight: 'var(--fw-semibold)',
    fontSize: fs,
    lineHeight: 1.2,
    padding: pad,
    border: 'none',
    borderRadius: 'var(--r-md)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'background .15s, box-shadow .15s, opacity .15s, filter .15s',
    whiteSpace: 'nowrap'
  };
  const variants = {
    primary: {
      background: ready ? 'var(--accent-ready)' : 'var(--accent)',
      color: 'var(--text-on-accent)',
      boxShadow: ready ? 'var(--shadow-ready)' : 'var(--shadow-sm)'
    },
    secondary: {
      background: 'var(--primary)',
      color: 'var(--text-on-mint)',
      boxShadow: 'none'
    },
    ghost: {
      background: 'var(--surface-page)',
      color: 'var(--sw-ink)',
      border: 'var(--border-card)',
      boxShadow: 'none'
    }
  };
  const disabledStyle = disabled ? {
    opacity: 0.38,
    filter: 'grayscale(.25)',
    boxShadow: 'none'
  } : {};
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    style: {
      ...base,
      ...variants[variant],
      ...disabledStyle,
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      fontSize: '1.05em',
      lineHeight: 1
    }
  }, icon), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
/**
 * SW ONE surface card — white, hairline border, 14px radius, 18px padding.
 * The default container for every panel in the product. Optional `title` renders the
 * product's `h2` card heading; `actions` sits on the right of the header row.
 */
function Card({
  title,
  actions,
  children,
  padding,
  style = {},
  bodyStyle = {}
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-card)',
      border: 'var(--border-card)',
      borderRadius: 'var(--r-xl)',
      padding: padding != null ? padding : 'var(--sp-6)',
      marginBottom: 'var(--sp-5)',
      color: 'var(--text-body)',
      boxShadow: 'var(--shadow-card)',
      ...style
    }
  }, (title || actions) && /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--sp-3)',
      marginBottom: 'var(--sp-3)'
    }
  }, title && /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-card-title)',
      margin: 0
    }
  }, title), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--sp-2)',
      alignItems: 'center'
    }
  }, actions)), /*#__PURE__*/React.createElement("div", {
    style: bodyStyle
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/KpiCard.jsx
try { (() => {
/**
 * SW ONE KPI tile — maximally minimal: a clean white card with a small uppercase tracked
 * caption and a large near-black figure. Optional `delta` adds a discreet trend chip.
 * No accent rails, no fills — the number carries the card.
 */
function KpiCard({
  label,
  value,
  prefix = '',
  suffix = '',
  delta,
  deltaTone = 'good',
  hint,
  tone,
  style = {}
}) {
  const dColor = deltaTone === 'bad' ? 'var(--sw-bad)' : 'var(--sw-green-700)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      border: 'var(--border-card)',
      borderRadius: 'var(--r-xl)',
      padding: 'var(--sp-5)',
      boxShadow: 'var(--shadow-card)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--sp-2)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-2xs)',
      letterSpacing: 'var(--ls-label)',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      fontWeight: 'var(--fw-semibold)'
    }
  }, label), delta != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-2xs)',
      fontWeight: 'var(--fw-semibold)',
      color: dColor,
      whiteSpace: 'nowrap'
    }
  }, delta)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-h1)',
      fontWeight: 'var(--fw-semibold)',
      marginTop: '8px',
      fontVariantNumeric: 'tabular-nums',
      letterSpacing: '-.015em',
      color: 'var(--text-strong)'
    }
  }, prefix, value, suffix), hint && /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-hint)',
      color: 'var(--text-muted)',
      marginTop: '4px'
    }
  }, hint));
}
Object.assign(__ds_scope, { KpiCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/KpiCard.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
/**
 * SW ONE data table — borderless rows with hairline rules, muted header, tabular numerics.
 * `columns` is [{ key, header, align, render }]; numeric columns (align:"right") get
 * tabular-nums automatically. Pass `footer` for a totals row.
 */
function DataTable({
  columns = [],
  rows = [],
  footer,
  getRowKey,
  style = {}
}) {
  const cell = align => ({
    textAlign: align === 'right' ? 'right' : 'left',
    padding: '8px 10px',
    borderBottom: 'var(--border-card)',
    fontVariantNumeric: align === 'right' ? 'tabular-nums' : 'normal'
  });
  return /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 'var(--fs-sm)',
      fontFamily: 'var(--font-body)',
      color: 'var(--text-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      ...cell(c.align),
      color: 'var(--sw-muted)',
      fontWeight: 'var(--fw-semibold)'
    }
  }, c.header)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((row, i) => /*#__PURE__*/React.createElement("tr", {
    key: getRowKey ? getRowKey(row, i) : i
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: cell(c.align)
  }, c.render ? c.render(row[c.key], row, i) : row[c.key]))))), footer && /*#__PURE__*/React.createElement("tfoot", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      fontWeight: 'var(--fw-bold)'
    }
  }, footer.map((f, i) => /*#__PURE__*/React.createElement("td", {
    key: i,
    style: {
      ...cell(f.align),
      borderBottom: 'none'
    }
  }, f.content)))));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SW ONE labelled select — matches TextField styling. `options` is an array of
 * { value, label } or plain strings. Used heavily for account pickers, cf-activity,
 * assignee, currency, etc.
 */
function Select({
  label,
  hint,
  required = false,
  size = 'md',
  value,
  defaultValue,
  options = [],
  placeholder,
  onChange,
  disabled = false,
  style = {},
  selectStyle = {},
  ...rest
}) {
  const pad = size === 'lg' ? '14px 16px' : '8px 10px';
  const fs = size === 'lg' ? '16px' : 'var(--fs-sm)';
  const norm = options.map(o => typeof o === 'string' ? {
    value: o,
    label: o
  } : o);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '3px',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-hint)',
      color: 'var(--sw-muted)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--sw-bad)'
    }
  }, " *")), /*#__PURE__*/React.createElement("select", _extends({
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    disabled: disabled,
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: fs,
      padding: pad,
      border: 'var(--border-card)',
      borderRadius: 'var(--r-sm)',
      background: disabled ? 'var(--surface-page)' : 'var(--surface-card)',
      color: 'var(--text-body)',
      width: '100%',
      ...selectStyle
    }
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, placeholder), norm.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-hint)',
      color: 'var(--sw-muted)'
    }
  }, hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SW ONE labelled text field — the stacked label + input used across every form.
 * Hairline border, 8px radius. `required` shows the product's trailing asterisk in the label.
 * Inputs render at 14px (16px on the login card to stop iOS zoom — pass size="lg").
 */
function TextField({
  label,
  hint,
  required = false,
  size = 'md',
  type = 'text',
  value,
  defaultValue,
  placeholder,
  onChange,
  disabled = false,
  style = {},
  inputStyle = {},
  ...rest
}) {
  const pad = size === 'lg' ? '14px 16px' : '8px 10px';
  const fs = size === 'lg' ? '16px' : 'var(--fs-sm)';
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '3px',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-hint)',
      color: 'var(--sw-muted)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--sw-bad)'
    }
  }, " *")), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    onChange: onChange,
    disabled: disabled,
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: fs,
      padding: pad,
      border: 'var(--border-card)',
      borderRadius: 'var(--r-sm)',
      background: disabled ? 'var(--surface-page)' : 'var(--surface-card)',
      color: 'var(--text-body)',
      width: '100%',
      ...inputStyle
    }
  }, rest)), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-hint)',
      color: 'var(--sw-muted)'
    }
  }, hint));
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/navigation/GroupNav.jsx
try { (() => {
/**
 * SW ONE top-level group nav — the row of group buttons on the pale-sage bar.
 * Active group is white with a soft lift. `items` is [{ key, label }]; the product's
 * groups are Executive Dashboard / To-Do Board / CRM / Inventory / HR / Tax / Assets / Reports / Settings.
 */
function GroupNav({
  items = [],
  active,
  onSelect,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 'var(--sp-1)',
      flexWrap: 'wrap',
      padding: 'var(--sp-2) var(--sp-6)',
      background: 'var(--surface-nav)',
      borderBottom: 'var(--border-card)',
      ...style
    }
  }, items.map(it => {
    const on = it.key === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.key,
      onClick: () => onSelect && onSelect(it.key),
      style: {
        border: on ? '1px solid var(--nav-active-border)' : '1px solid transparent',
        background: on ? 'var(--nav-active-bg)' : 'transparent',
        padding: '7px 14px',
        borderRadius: 'var(--r-pill)',
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--fs-sm)',
        fontWeight: on ? 'var(--fw-semibold)' : 'var(--fw-medium)',
        color: on ? 'var(--nav-active-fg)' : 'var(--text-muted)',
        cursor: 'pointer',
        whiteSpace: 'nowrap',
        transition: 'background .15s, color .15s'
      }
    }, it.label);
  }));
}
Object.assign(__ds_scope, { GroupNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/GroupNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SubNavChips.jsx
try { (() => {
/**
 * SW ONE second-level sub-nav — the row of rounded cream chips on the white bar.
 * Active chip fills mint. Shown under GroupNav when a group has more than one view.
 */
function SubNavChips({
  items = [],
  active,
  onSelect,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--sp-1)',
      flexWrap: 'wrap',
      padding: 'var(--sp-2) var(--sp-6)',
      background: 'var(--surface-card)',
      borderBottom: 'var(--border-card)',
      ...style
    }
  }, items.map(it => {
    const on = it.key === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.key,
      onClick: () => onSelect && onSelect(it.key),
      style: {
        border: on ? '1px solid var(--nav-active-border)' : '1px solid transparent',
        background: on ? 'var(--nav-active-bg)' : 'transparent',
        padding: '6px 13px',
        borderRadius: 'var(--r-pill)',
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--fs-xs)',
        fontWeight: on ? 'var(--fw-semibold)' : 'var(--fw-medium)',
        color: on ? 'var(--nav-active-fg)' : 'var(--text-muted)',
        cursor: 'pointer',
        whiteSpace: 'nowrap',
        transition: 'background .15s, color .15s'
      }
    }, it.label);
  }));
}
Object.assign(__ds_scope, { SubNavChips });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SubNavChips.jsx", error: String((e && e.message) || e) }); }

// ui_kits/sw-one-erp/DashboardScreen.jsx
try { (() => {
/* global React */
// SW ONE — Executive Dashboard. KPI row, job-status doughnut (CSS conic), AR/AP aging bars,
// cash-flow direct table. Cosmetic recreation — figures are illustrative.
const DashDS = window.SWONEDesignSystem_31b001;
function MiniBars({
  data,
  color
}) {
  const max = Math.max(...data.map(d => d.v), 1);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 18,
      height: 150,
      padding: '8px 4px'
    }
  }, data.map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 46,
      height: `${d.v / max * 110}px`,
      background: color,
      borderRadius: '6px 6px 0 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-2xs)',
      color: 'var(--sw-muted)'
    }
  }, d.label))));
}
function DashboardScreen() {
  const {
    KpiCard,
    Card,
    DataTable
  } = DashDS;
  const done = 7,
    hand = 4,
    quote = 3,
    total = done + hand + quote;
  const a = done / total * 360,
    b = a + hand / total * 360;
  const pie = `conic-gradient(var(--sw-good) 0 ${a}deg, var(--sw-mint-300) ${a}deg ${b}deg, var(--sw-warn) ${b}deg 360deg)`;
  const ar = [{
    label: '<30',
    v: 420
  }, {
    label: '30-60',
    v: 180
  }, {
    label: '60-90',
    v: 90
  }, {
    label: '90+',
    v: 40
  }];
  const ap = [{
    label: '<30',
    v: 260
  }, {
    label: '30-60',
    v: 120
  }, {
    label: '60-90',
    v: 60
  }, {
    label: '90+',
    v: 20
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))',
      gap: 'var(--sp-4)',
      marginBottom: 'var(--sp-5)'
    }
  }, /*#__PURE__*/React.createElement(KpiCard, {
    label: "\u0E23\u0E32\u0E22\u0E44\u0E14\u0E49\u0E23\u0E27\u0E21",
    prefix: "\u0E3F",
    value: "1,284,500.00",
    delta: "+12.4%",
    deltaTone: "good"
  }), /*#__PURE__*/React.createElement(KpiCard, {
    label: "\u0E01\u0E33\u0E44\u0E23\u0E2A\u0E38\u0E17\u0E18\u0E34",
    prefix: "\u0E3F",
    value: "312,940.00",
    delta: "+8.1%",
    deltaTone: "good"
  }), /*#__PURE__*/React.createElement(KpiCard, {
    label: "\u0E2A\u0E34\u0E19\u0E17\u0E23\u0E31\u0E1E\u0E22\u0E4C\u0E23\u0E27\u0E21",
    prefix: "\u0E3F",
    value: "2,907,310.00",
    tone: "plain"
  }), /*#__PURE__*/React.createElement(KpiCard, {
    label: "\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E1B\u0E25\u0E07\u0E2A\u0E38\u0E17\u0E18\u0E34",
    prefix: "\u0E3F",
    value: "184,220.00",
    tone: "rose",
    delta: "\u22123.2%",
    deltaTone: "bad"
  }), /*#__PURE__*/React.createElement(KpiCard, {
    label: "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19",
    value: "8",
    suffix: " \u0E04\u0E19",
    tone: "plain"
  })), /*#__PURE__*/React.createElement(Card, {
    title: "\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E07\u0E32\u0E19 (\u0E27\u0E07\u0E08\u0E23\u0E07\u0E32\u0E19)"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 24,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 180,
      height: 180,
      borderRadius: '50%',
      background: pie,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 28,
      borderRadius: '50%',
      background: 'var(--surface-card)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-h1)',
      fontWeight: 700
    }
  }, total), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-2xs)',
      color: 'var(--sw-muted)'
    }
  }, "\u0E07\u0E32\u0E19\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14"))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-body)',
      lineHeight: 2
    }
  }, /*#__PURE__*/React.createElement("div", null, "\uD83D\uDFE2 \u0E2A\u0E48\u0E07\u0E21\u0E2D\u0E1A\u0E41\u0E25\u0E49\u0E27: ", /*#__PURE__*/React.createElement("b", null, done)), /*#__PURE__*/React.createElement("div", null, "\uD83D\uDD35 \u0E07\u0E32\u0E19\u0E43\u0E19\u0E21\u0E37\u0E2D (\u0E01\u0E33\u0E25\u0E31\u0E07\u0E17\u0E33): ", /*#__PURE__*/React.createElement("b", null, hand)), /*#__PURE__*/React.createElement("div", null, "\uD83D\uDFE1 \u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E2A\u0E19\u0E2D\u0E25\u0E39\u0E01\u0E04\u0E49\u0E32: ", /*#__PURE__*/React.createElement("b", null, quote))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))',
      gap: 'var(--sp-4)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "\u0E2D\u0E32\u0E22\u0E38\u0E25\u0E39\u0E01\u0E2B\u0E19\u0E35\u0E49\u0E04\u0E49\u0E32\u0E07\u0E0A\u0E33\u0E23\u0E30 (AR Aging)"
  }, /*#__PURE__*/React.createElement(MiniBars, {
    data: ar,
    color: "var(--sw-mint-300)"
  })), /*#__PURE__*/React.createElement(Card, {
    title: "\u0E2D\u0E32\u0E22\u0E38\u0E40\u0E08\u0E49\u0E32\u0E2B\u0E19\u0E35\u0E49\u0E04\u0E49\u0E32\u0E07\u0E0A\u0E33\u0E23\u0E30 (AP Aging)"
  }, /*#__PURE__*/React.createElement(MiniBars, {
    data: ap,
    color: "var(--sw-rose)"
  }))), /*#__PURE__*/React.createElement(Card, {
    title: "\u0E07\u0E1A\u0E01\u0E23\u0E30\u0E41\u0E2A\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14 (Direct) \u2014 Priority 1"
  }, /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'k',
      header: 'กิจกรรม'
    }, {
      key: 'v',
      header: 'จำนวนเงิน',
      align: 'right'
    }],
    rows: [{
      k: 'กิจกรรมดำเนินงาน (O)',
      v: '฿268,400.00'
    }, {
      k: 'กิจกรรมลงทุน (I)',
      v: '−฿94,180.00'
    }, {
      k: 'กิจกรรมจัดหาเงิน (F)',
      v: '฿10,000.00'
    }],
    footer: [{
      content: 'เงินสดเปลี่ยนแปลงสุทธิ'
    }, {
      content: '฿184,220.00',
      align: 'right'
    }]
  })));
}
window.DashboardScreen = DashboardScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sw-one-erp/DashboardScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/sw-one-erp/DocumentsScreen.jsx
try { (() => {
/* global React */
// SW ONE — Tax invoice document (A4 paper). Letterhead + line table + VAT totals + signature.
const DocDS = window.SWONEDesignSystem_31b001;
function DocumentsScreen() {
  const {
    Card,
    Button,
    DataTable
  } = DocDS;
  const lines = [{
    i: 1,
    d: 'งานวางระบบบัญชี ERP — เฟส 1',
    q: 1,
    u: '85,000.00',
    a: '85,000.00'
  }, {
    i: 2,
    d: 'อบรมการใช้งานระบบ (2 วัน)',
    q: 2,
    u: '12,000.00',
    a: '24,000.00'
  }, {
    i: 3,
    d: 'ค่าที่ปรึกษารายเดือน',
    q: 1,
    u: '3,149.53',
    a: '3,149.53'
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 'var(--sp-4)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "\uD83D\uDDA8"
  }, "\u0E1E\u0E34\u0E21\u0E1E\u0E4C / \u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01 PDF"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: "\u270F\uFE0F"
  }, "\u0E41\u0E01\u0E49\u0E44\u0E02\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost"
  }, "\u2715 \u0E1B\u0E34\u0E14")), /*#__PURE__*/React.createElement(Card, {
    padding: 28,
    style: {
      maxWidth: 760,
      margin: '0 auto',
      lineHeight: 'var(--lh-relaxed)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      borderBottom: '2px solid var(--sw-gold)',
      paddingBottom: 10,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-sw.jpg",
    alt: "",
    style: {
      height: 66,
      width: 66,
      objectFit: 'contain'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 'var(--fs-h3)'
    }
  }, "\u0E1A\u0E23\u0E34\u0E29\u0E31\u0E17 \u0E40\u0E2D\u0E2A \u0E14\u0E31\u0E1A\u0E40\u0E1A\u0E34\u0E25\u0E22\u0E39 \u0E2A\u0E41\u0E15\u0E23\u0E17\u0E35\u0E08\u0E34\u0E01 \u0E42\u0E0B\u0E25\u0E39\u0E0A\u0E31\u0E19\u0E2A\u0E4C \u0E01\u0E23\u0E38\u0E4A\u0E1B \u0E08\u0E33\u0E01\u0E31\u0E14"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-2xs)',
      color: 'var(--sw-muted)'
    }
  }, "SW Strategic Solutions Group Co., Ltd."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-2xs)',
      color: 'var(--sw-muted)'
    }
  }, "\u0E40\u0E25\u0E02\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E19\u0E34\u0E15\u0E34\u0E1A\u0E38\u0E04\u0E04\u0E25 0125569020330"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-2xs)',
      color: 'var(--sw-muted)'
    }
  }, "\u0E42\u0E17\u0E23 0641549955 \xB7 v.suwatvanich@swstrategicsol.com"))), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right',
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 700,
      color: 'var(--sw-gold-ink)'
    }
  }, "\u0E43\u0E1A\u0E01\u0E33\u0E01\u0E31\u0E1A\u0E20\u0E32\u0E29\u0E35"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-2xs)',
      color: 'var(--sw-muted)'
    }
  }, "TAX INVOICE"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-xs)',
      marginTop: 4
    }
  }, "\u0E40\u0E25\u0E02\u0E17\u0E35\u0E48 INV-2026-0042"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-xs)'
    }
  }, "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 2026-06-22"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-xs)',
      color: 'var(--sw-muted)'
    }
  }, "\u0E04\u0E23\u0E1A\u0E01\u0E33\u0E2B\u0E19\u0E14 2026-07-22"))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12,
      fontSize: 'var(--fs-sm)'
    }
  }, /*#__PURE__*/React.createElement("b", null, "\u0E25\u0E39\u0E01\u0E04\u0E49\u0E32:"), " \u0E1A\u0E23\u0E34\u0E29\u0E31\u0E17 \u0E40\u0E2D\u0E1A\u0E35\u0E0B\u0E35 \u0E40\u0E17\u0E23\u0E14\u0E14\u0E34\u0E49\u0E07 \u0E08\u0E33\u0E01\u0E31\u0E14 \xB7 \u0E40\u0E25\u0E02\u0E20\u0E32\u0E29\u0E35 0105560000123"), /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'i',
      header: '#',
      align: 'right'
    }, {
      key: 'd',
      header: 'รายการ'
    }, {
      key: 'q',
      header: 'จำนวน',
      align: 'right'
    }, {
      key: 'u',
      header: 'ราคา/หน่วย',
      align: 'right',
      render: v => '฿' + v
    }, {
      key: 'a',
      header: 'จำนวนเงิน',
      align: 'right',
      render: v => '฿' + v
    }],
    rows: lines
  }), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      marginTop: 4,
      fontSize: 'var(--fs-sm)'
    }
  }, /*#__PURE__*/React.createElement("tbody", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      padding: '4px 10px'
    }
  }, "\u0E23\u0E27\u0E21\u0E01\u0E48\u0E2D\u0E19\u0E20\u0E32\u0E29\u0E35"), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      padding: '4px 10px',
      width: 140,
      fontVariantNumeric: 'tabular-nums'
    }
  }, "\u0E3F112,149.53")), /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      padding: '4px 10px'
    }
  }, "VAT 7%"), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      padding: '4px 10px',
      fontVariantNumeric: 'tabular-nums'
    }
  }, "\u0E3F7,850.47")), /*#__PURE__*/React.createElement("tr", {
    style: {
      fontWeight: 700
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      padding: '6px 10px',
      borderTop: '1px solid var(--sw-line)'
    }
  }, "\u0E23\u0E27\u0E21\u0E17\u0E31\u0E49\u0E07\u0E2A\u0E34\u0E49\u0E19"), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      padding: '6px 10px',
      borderTop: '1px solid var(--sw-line)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, "\u0E3F120,000.00")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      marginTop: 30
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      width: '45%'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/signature-veerachai.png",
    alt: "",
    style: {
      height: 46,
      objectFit: 'contain'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid #333',
      marginTop: 4,
      fontSize: 'var(--fs-xs)'
    }
  }, "\u0E1C\u0E39\u0E49\u0E21\u0E35\u0E2D\u0E33\u0E19\u0E32\u0E08\u0E25\u0E07\u0E19\u0E32\u0E21"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 'var(--fs-sm)'
    }
  }, "\u0E27\u0E35\u0E23\u0E30\u0E0A\u0E31\u0E22 \u0E2A\u0E38\u0E27\u0E31\u0E08\u0E19\u0E4C\u0E27\u0E13\u0E34\u0E0A")), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      width: '45%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 46
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid #333',
      marginTop: 4,
      fontSize: 'var(--fs-xs)'
    }
  }, "\u0E1C\u0E39\u0E49\u0E23\u0E31\u0E1A\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23")))));
}
window.DocumentsScreen = DocumentsScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sw-one-erp/DocumentsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/sw-one-erp/JournalScreen.jsx
try { (() => {
/* global React */
// SW ONE — Journal entry (ลงบัญชี). The product's signature view: real-time debit/credit
// diff, mandatory cash-flow activity when a cash account is touched, gated save button.
const JrnDS = window.SWONEDesignSystem_31b001;
const ACCOUNTS = [{
  code: '1101',
  name: 'เงินสด',
  cash: true
}, {
  code: '1102',
  name: 'เงินฝากธนาคาร - กระแสรายวัน',
  cash: true
}, {
  code: '1141',
  name: 'ลูกหนี้การค้า',
  cash: false
}, {
  code: '2151',
  name: 'ภาษีขาย',
  cash: false
}, {
  code: '4101',
  name: 'รายได้ค่าบริการ',
  cash: false
}, {
  code: '5101',
  name: 'ต้นทุนบริการ',
  cash: false
}];
const CF = [{
  value: 'O',
  label: 'ดำเนินงาน (O)'
}, {
  value: 'I',
  label: 'ลงทุน (I)'
}, {
  value: 'F',
  label: 'จัดหาเงิน (F)'
}];
function JournalScreen() {
  const {
    Card,
    Button,
    Select,
    Badge
  } = JrnDS;
  const [rows, setRows] = React.useState([{
    id: 1,
    acc: '1102',
    debit: '120000',
    credit: '',
    cf: 'O'
  }, {
    id: 2,
    acc: '4101',
    debit: '',
    credit: '112149.53',
    cf: ''
  }, {
    id: 3,
    acc: '2151',
    debit: '',
    credit: '7850.47',
    cf: ''
  }]);
  const set = (id, k, v) => setRows(rs => rs.map(r => r.id === id ? {
    ...r,
    [k]: v
  } : r));
  const addRow = () => setRows(rs => [...rs, {
    id: Date.now(),
    acc: '',
    debit: '',
    credit: '',
    cf: ''
  }]);
  const delRow = id => setRows(rs => rs.filter(r => r.id !== id));
  const num = s => parseFloat(s || 0) || 0;
  const totD = rows.reduce((s, r) => s + num(r.debit), 0);
  const totC = rows.reduce((s, r) => s + num(r.credit), 0);
  const diff = totD - totC;
  const touchesCash = rows.some(r => (ACCOUNTS.find(a => a.code === r.acc) || {}).cash);
  const cfMissing = touchesCash && rows.some(r => {
    const isCash = (ACCOUNTS.find(a => a.code === r.acc) || {}).cash;
    return !isCash && r.acc && (num(r.debit) || num(r.credit)) && !r.cf;
  });
  const balanced = Math.abs(diff) < 0.005 && totD > 0;
  const canSave = balanced && rows.filter(r => r.acc).length >= 2 && !cfMissing;
  const fmt = n => n.toLocaleString('th-TH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const accOpts = [{
    value: '',
    label: '— เลือกบัญชี —'
  }, ...ACCOUNTS.map(a => ({
    value: a.code,
    label: `${a.code} ${a.name}`
  }))];
  return /*#__PURE__*/React.createElement("div", null, touchesCash && /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--sw-warn-bg)',
      border: '1px solid var(--sw-warn)',
      color: '#8a6418',
      borderRadius: 'var(--r-lg)',
      padding: '10px 12px',
      fontSize: 'var(--fs-xs)',
      marginBottom: 'var(--sp-4)'
    }
  }, "\u26A0\uFE0F \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E41\u0E15\u0E30 ", /*#__PURE__*/React.createElement("b", null, "\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14/\u0E40\u0E17\u0E35\u0E22\u0E1A\u0E40\u0E17\u0E48\u0E32\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14"), " \u2014 \u0E17\u0E38\u0E01\u0E02\u0E32\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14\u0E15\u0E49\u0E2D\u0E07\u0E23\u0E30\u0E1A\u0E38 ", /*#__PURE__*/React.createElement("b", null, "\u0E01\u0E34\u0E08\u0E01\u0E23\u0E23\u0E21\u0E01\u0E23\u0E30\u0E41\u0E2A\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14 (O/I/F)"), " \u0E01\u0E48\u0E2D\u0E19\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01"), /*#__PURE__*/React.createElement(Card, {
    title: "\u0E25\u0E07\u0E1A\u0E31\u0E0D\u0E0A\u0E35 (\u0E2A\u0E21\u0E38\u0E14\u0E23\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E31\u0E48\u0E27\u0E44\u0E1B)"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.7fr 1fr 1fr 1fr 32px',
      gap: 8,
      fontSize: 'var(--fs-2xs)',
      color: 'var(--sw-muted)',
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement("span", null, "\u0E1A\u0E31\u0E0D\u0E0A\u0E35"), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: 'right'
    }
  }, "\u0E40\u0E14\u0E1A\u0E34\u0E15"), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: 'right'
    }
  }, "\u0E40\u0E04\u0E23\u0E14\u0E34\u0E15"), /*#__PURE__*/React.createElement("span", null, "\u0E01\u0E34\u0E08\u0E01\u0E23\u0E23\u0E21"), /*#__PURE__*/React.createElement("span", null)), rows.map(r => {
    const isCash = (ACCOUNTS.find(a => a.code === r.acc) || {}).cash;
    const needCf = touchesCash && !isCash && r.acc && (num(r.debit) || num(r.credit)) && !r.cf;
    return /*#__PURE__*/React.createElement("div", {
      key: r.id,
      style: {
        display: 'grid',
        gridTemplateColumns: '1.7fr 1fr 1fr 1fr 32px',
        gap: 8,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("select", {
      value: r.acc,
      onChange: e => set(r.id, 'acc', e.target.value),
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--fs-sm)',
        padding: '8px 10px',
        border: 'var(--border-card)',
        borderRadius: 'var(--r-sm)',
        background: '#fff'
      }
    }, accOpts.map(o => /*#__PURE__*/React.createElement("option", {
      key: o.value,
      value: o.value
    }, o.label))), /*#__PURE__*/React.createElement("input", {
      value: r.debit,
      onChange: e => set(r.id, 'debit', e.target.value),
      placeholder: "0.00",
      inputMode: "decimal",
      style: {
        textAlign: 'right',
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--fs-sm)',
        padding: '8px 10px',
        border: 'var(--border-card)',
        borderRadius: 'var(--r-sm)',
        fontVariantNumeric: 'tabular-nums'
      }
    }), /*#__PURE__*/React.createElement("input", {
      value: r.credit,
      onChange: e => set(r.id, 'credit', e.target.value),
      placeholder: "0.00",
      inputMode: "decimal",
      style: {
        textAlign: 'right',
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--fs-sm)',
        padding: '8px 10px',
        border: 'var(--border-card)',
        borderRadius: 'var(--r-sm)',
        fontVariantNumeric: 'tabular-nums'
      }
    }), isCash ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--fs-2xs)',
        color: 'var(--sw-muted)',
        textAlign: 'center'
      }
    }, "\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14") : /*#__PURE__*/React.createElement("select", {
      value: r.cf,
      onChange: e => set(r.id, 'cf', e.target.value),
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--fs-sm)',
        padding: '8px 6px',
        border: needCf ? '1px solid var(--sw-bad)' : 'var(--border-card)',
        borderRadius: 'var(--r-sm)',
        background: '#fff'
      }
    }, /*#__PURE__*/React.createElement("option", {
      value: ""
    }, "\u2014 \u0E01\u0E34\u0E08\u0E01\u0E23\u0E23\u0E21 \u2014"), CF.map(o => /*#__PURE__*/React.createElement("option", {
      key: o.value,
      value: o.value
    }, o.label))), /*#__PURE__*/React.createElement("button", {
      onClick: () => delRow(r.id),
      title: "\u0E25\u0E1A\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14",
      style: {
        border: 'none',
        background: 'transparent',
        color: 'var(--sw-muted)',
        cursor: 'pointer',
        fontSize: 16
      }
    }, "\u2715"));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      marginTop: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    icon: "\uFF0B",
    onClick: addRow
  }, "\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 18,
      alignItems: 'center',
      fontSize: 'var(--fs-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontVariantNumeric: 'tabular-nums'
    }
  }, "\u0E40\u0E14\u0E1A\u0E34\u0E15 ", /*#__PURE__*/React.createElement("b", null, "\u0E3F", fmt(totD))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontVariantNumeric: 'tabular-nums'
    }
  }, "\u0E40\u0E04\u0E23\u0E14\u0E34\u0E15 ", /*#__PURE__*/React.createElement("b", null, "\u0E3F", fmt(totC))), /*#__PURE__*/React.createElement(Badge, {
    tone: balanced ? 'good' : 'bad',
    dot: true
  }, "\u0E1C\u0E25\u0E15\u0E48\u0E32\u0E07 \u0E3F", fmt(diff))), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    ready: canSave,
    disabled: !canSave,
    title: canSave ? 'พร้อมบันทึก' : 'ยังบันทึกไม่ได้: ต้องดุล + มี ≥2 บรรทัด + ระบุกิจกรรมครบ',
    icon: "\uD83D\uDCBE"
  }, "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01")), cfMissing && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-xs)',
      color: 'var(--sw-bad)',
      marginTop: 8
    }
  }, "\u0E22\u0E31\u0E07\u0E23\u0E30\u0E1A\u0E38\u0E01\u0E34\u0E08\u0E01\u0E23\u0E23\u0E21\u0E01\u0E23\u0E30\u0E41\u0E2A\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14\u0E44\u0E21\u0E48\u0E04\u0E23\u0E1A \u2014 \u0E14\u0E39\u0E0A\u0E48\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E02\u0E2D\u0E1A\u0E2A\u0E35\u0E41\u0E14\u0E07")));
}
window.JournalScreen = JournalScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sw-one-erp/JournalScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/sw-one-erp/KanbanScreen.jsx
try { (() => {
/* global React */
// SW ONE — To-Do Board (Kanban). Drag-free interactive: move cards via the status select.
const KbDS = window.SWONEDesignSystem_31b001;
const COLS = [['Onhand', 'Onhand job'], ['InProcess', 'In Process'], ['Pending', 'Pending'], ['Done', 'Done']];
function KanbanScreen() {
  const {
    TaskCard,
    Card
  } = KbDS;
  const [tasks, setTasks] = React.useState([{
    id: 1,
    title: 'ปิดงบเดือนมิถุนายน',
    priority: 'Urgent',
    deadline: '2026-07-05',
    assignee: 'วีระชัย',
    status: 'Onhand'
  }, {
    id: 2,
    title: 'ตรวจ ภ.พ.30 งวด มิ.ย.',
    priority: 'High',
    deadline: '2026-07-15',
    assignee: 'ศิญาภัสร์',
    status: 'Onhand'
  }, {
    id: 3,
    title: 'ออกใบกำกับภาษี ลูกค้า ABC',
    priority: 'Normal',
    deadline: '2026-07-20',
    assignee: 'ศิญาภัสร์',
    status: 'InProcess'
  }, {
    id: 4,
    title: 'วางระบบ ERP เฟส 2',
    priority: 'High',
    deadline: '2026-08-01',
    assignee: 'วีระชัย',
    status: 'InProcess'
  }, {
    id: 5,
    title: 'ทบทวนผังบัญชี',
    priority: 'Low',
    deadline: '',
    assignee: 'วีระชัย',
    status: 'Pending'
  }, {
    id: 6,
    title: 'ยื่นประกันสังคม มิ.ย.',
    priority: 'Normal',
    deadline: '2026-06-15',
    assignee: 'ศิญาภัสร์',
    status: 'Done'
  }]);
  const today = '2026-06-22';
  const move = (id, status) => setTasks(ts => ts.map(t => t.id === id ? {
    ...t,
    status
  } : t));
  const dueTxt = dl => {
    if (!dl) return 'ไม่มีกำหนด';
    const d = Math.ceil((new Date(dl + 'T00:00:00') - new Date(today + 'T00:00:00')) / 86400000);
    if (d > 0) return `${dl} · เหลือ ${d} วัน`;
    if (d === 0) return `${dl} · ครบกำหนดวันนี้`;
    return `${dl} · เกินกำหนด ${-d} วัน`;
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 'var(--sp-3)'
    }
  }, COLS.map(([key, label]) => {
    const items = tasks.filter(t => t.status === key);
    return /*#__PURE__*/React.createElement("div", {
      key: key,
      style: {
        background: 'var(--surface-raised)',
        borderRadius: 'var(--r-lg)',
        padding: 10,
        minHeight: 160
      }
    }, /*#__PURE__*/React.createElement("h3", {
      style: {
        margin: '2px 0 10px',
        fontSize: 'var(--fs-h3)',
        display: 'flex',
        justifyContent: 'space-between'
      }
    }, /*#__PURE__*/React.createElement("span", null, label), /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--sw-muted)',
        fontWeight: 400
      }
    }, items.length)), items.map(t => /*#__PURE__*/React.createElement(TaskCard, {
      key: t.id,
      title: t.title,
      priority: t.priority,
      due: t.deadline ? dueTxt(t.deadline) : null,
      overdue: t.deadline && t.deadline < today && t.status !== 'Done',
      assignee: t.assignee,
      meta: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, /*#__PURE__*/React.createElement("select", {
        value: t.status,
        onChange: e => move(t.id, e.target.value),
        style: {
          fontFamily: 'var(--font-body)',
          fontSize: 'var(--fs-2xs)',
          padding: '2px 6px',
          border: 'var(--border-card)',
          borderRadius: 'var(--r-sm)',
          background: '#fff'
        }
      }, COLS.map(([k, l]) => /*#__PURE__*/React.createElement("option", {
        key: k,
        value: k
      }, l))))
    })), items.length === 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 'var(--fs-xs)',
        color: 'var(--sw-muted)',
        textAlign: 'center',
        padding: '14px 0'
      }
    }, "\u2014 \u0E27\u0E48\u0E32\u0E07 \u2014"));
  }));
}
window.KanbanScreen = KanbanScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sw-one-erp/KanbanScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/sw-one-erp/LoginScreen.jsx
try { (() => {
/* global React */
// SW ONE — Login. Theme-aware brand moment:
//  light → mint gradient + bark/leaf Yggdrasil corners, white card
//  dark  → deep navy gradient + GOLD glowing Yggdrasil corners, navy card, gold CTA
// `dark` + `onToggleDark` come from App so the choice carries into the app shell.
const {
  Button: SWButton
} = window.SWONEDesignSystem_31b001;
function LoginScreen({
  onLogin,
  dark = false,
  onToggleDark
}) {
  const [user, setUser] = React.useState('');
  const [pass, setPass] = React.useState('');
  const ready = !!(user && pass);
  const vineUrl = dark ? '../../assets/yggdrasil-vine-gold.svg' : '../../assets/yggdrasil-vine.svg';
  const fieldBg = dark ? 'var(--surface-sunken)' : '#fff';
  const submit = () => {
    if (ready) onLogin(user);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: dark ? 'radial-gradient(120% 120% at 50% 0%, #1B2747 0%, #0E1525 70%)' : 'linear-gradient(135deg, var(--sw-mint), var(--sw-mint-50))',
      overflow: 'hidden'
    }
  }, [['tl', {}], ['tr', {
    transform: 'scaleX(-1)'
  }], ['bl', {
    transform: 'scaleY(-1)'
  }], ['br', {
    transform: 'scale(-1,-1)'
  }]].map(([pos, tf]) => /*#__PURE__*/React.createElement("img", {
    key: pos,
    src: vineUrl,
    alt: "",
    style: {
      position: 'fixed',
      width: 170,
      height: 280,
      opacity: dark ? 0.85 : 0.5,
      pointerEvents: 'none',
      top: pos[0] === 't' ? -12 : 'auto',
      bottom: pos[0] === 'b' ? -12 : 'auto',
      left: pos[1] === 'l' ? -12 : 'auto',
      right: pos[1] === 'r' ? -12 : 'auto',
      ...tf
    }
  })), onToggleDark && /*#__PURE__*/React.createElement("button", {
    onClick: onToggleDark,
    title: "\u0E2A\u0E25\u0E31\u0E1A\u0E42\u0E2B\u0E21\u0E14\u0E21\u0E37\u0E14 / \u0E2A\u0E27\u0E48\u0E32\u0E07",
    style: {
      position: 'fixed',
      top: 18,
      right: 18,
      zIndex: 3,
      cursor: 'pointer',
      border: `1px solid ${dark ? 'var(--sw-line)' : 'rgba(40,51,46,.18)'}`,
      background: dark ? 'rgba(255,255,255,.06)' : 'rgba(255,255,255,.55)',
      color: dark ? 'var(--sw-gold-ink)' : 'var(--sw-ink)',
      borderRadius: 'var(--r-pill)',
      padding: '7px 14px',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--fs-xs)',
      fontWeight: 600
    }
  }, dark ? '☀️ สว่าง' : '🌙 มืด'), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 2,
      background: 'var(--surface-card)',
      padding: '48px 56px',
      borderRadius: 'var(--r-brand)',
      boxShadow: 'var(--shadow-modal)',
      width: 520,
      maxWidth: '92vw',
      textAlign: 'center',
      border: dark ? '1px solid var(--sw-line)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-sw.jpg",
    alt: "SW ONE",
    style: {
      height: 150,
      objectFit: 'contain',
      marginBottom: 4,
      borderRadius: dark ? 14 : 0,
      background: dark ? '#fff' : 'transparent',
      padding: dark ? 8 : 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-display)',
      fontWeight: 600,
      letterSpacing: 'var(--ls-wordmark)',
      color: 'var(--text-strong)',
      margin: '2px 0'
    }
  }, "SW ONE"), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 44,
      height: 2,
      margin: '4px auto 12px',
      borderRadius: 2,
      background: dark ? 'var(--sw-gold)' : 'var(--sw-mint)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-sm)',
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--sw-muted)',
      marginBottom: 14
    }
  }, "Enterprise Business Suite"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-sm)',
      fontWeight: 600,
      color: 'var(--text-body)'
    }
  }, "\u0E1A\u0E23\u0E34\u0E29\u0E31\u0E17 \u0E40\u0E2D\u0E2A \u0E14\u0E31\u0E1A\u0E40\u0E1A\u0E34\u0E25\u0E22\u0E39 \u0E2A\u0E41\u0E15\u0E23\u0E17\u0E35\u0E08\u0E34\u0E01 \u0E42\u0E0B\u0E25\u0E39\u0E0A\u0E31\u0E19\u0E2A\u0E4C \u0E01\u0E23\u0E38\u0E4A\u0E1B \u0E08\u0E33\u0E01\u0E31\u0E14"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-xs)',
      color: 'var(--sw-muted)',
      marginBottom: 22
    }
  }, "\u0E40\u0E25\u0E02\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E19\u0E34\u0E15\u0E34\u0E1A\u0E38\u0E04\u0E04\u0E25 0125569020330"), /*#__PURE__*/React.createElement("select", {
    value: user,
    onChange: e => setUser(e.target.value),
    style: {
      width: '100%',
      marginBottom: 16,
      padding: '14px 16px',
      fontSize: 16,
      borderRadius: 'var(--r-lg)',
      border: 'var(--border-card)',
      background: fieldBg,
      fontFamily: 'var(--font-body)',
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, "\u2014 \u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49 \u2014"), /*#__PURE__*/React.createElement("option", {
    value: "\u0E27\u0E35\u0E23\u0E30\u0E0A\u0E31\u0E22"
  }, "\u0E27\u0E35\u0E23\u0E30\u0E0A\u0E31\u0E22 (veerachai_su)"), /*#__PURE__*/React.createElement("option", {
    value: "\u0E28\u0E34\u0E0D\u0E32\u0E20\u0E31\u0E2A\u0E23\u0E4C"
  }, "\u0E28\u0E34\u0E0D\u0E32\u0E20\u0E31\u0E2A\u0E23\u0E4C (Siyaphat_ch)"), /*#__PURE__*/React.createElement("option", {
    value: "demo"
  }, "\uD83E\uDDEA \u0E17\u0E14\u0E25\u0E2D\u0E07\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 (demo)")), /*#__PURE__*/React.createElement("input", {
    type: "password",
    placeholder: "\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19",
    value: pass,
    onChange: e => setPass(e.target.value),
    onKeyDown: e => e.key === 'Enter' && submit(),
    style: {
      width: '100%',
      marginBottom: 16,
      padding: '14px 16px',
      fontSize: 16,
      borderRadius: 'var(--r-lg)',
      border: 'var(--border-card)',
      background: fieldBg,
      color: 'var(--text-body)',
      fontFamily: 'var(--font-body)',
      boxSizing: 'border-box'
    }
  }), /*#__PURE__*/React.createElement(SWButton, {
    variant: "primary",
    ready: ready,
    disabled: !ready,
    onClick: submit,
    style: {
      width: '100%',
      padding: 16,
      fontSize: 18,
      letterSpacing: 1,
      borderRadius: 'var(--r-2xl)'
    }
  }, "\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-xs)',
      color: 'var(--sw-muted)',
      marginTop: 14
    }
  }, "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E43\u0E14\u0E01\u0E47\u0E44\u0E14\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E23\u0E2B\u0E31\u0E2A\u0E2D\u0E30\u0E44\u0E23\u0E01\u0E47\u0E44\u0E14\u0E49\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E25\u0E2D\u0E07\u0E40\u0E25\u0E48\u0E19")));
}
window.LoginScreen = LoginScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sw-one-erp/LoginScreen.jsx", error: String((e && e.message) || e) }); }

__ds_ns.TaskCard = __ds_scope.TaskCard;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.KpiCard = __ds_scope.KpiCard;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.GroupNav = __ds_scope.GroupNav;

__ds_ns.SubNavChips = __ds_scope.SubNavChips;

})();
